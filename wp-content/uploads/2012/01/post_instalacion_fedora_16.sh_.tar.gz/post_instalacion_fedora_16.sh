#!/bin/bash
##RPMFUSION##
yum localinstall --nogpgcheck http://download1.rpmfusion.org/free/fedora/rpmfusion-free-release-stable.noarch.rpm http://download1.rpmfusion.org/nonfree/fedora/rpmfusion-nonfree-release-stable.noarch.rpm
## Adobe Repository 32-bit x86 ##
rpm -ivh http://linuxdownload.adobe.com/adobe-release/adobe-release-i386-1.0-1.noarch.rpm
rpm --import /etc/pki/rpm-gpg/RPM-GPG-KEY-adobe-linux
#Livna
rpm -ivh http://rpm.livna.org/livna-release.rpm
#Chromium
wget http://repos.fedorapeople.org/repos/spot/chromium-stable/fedora-chromium-stable.repo
cp fedora-chromium-stable.repo /etc/yum.repos.d
#Actualización
yum update -y
##CODECS##
yum -y install gstreamer-plugins-bad gstreamer-plugins-bad-free-extras gstreamer-plugins-bad-nonfree gstreamer-plugins-ugly gstreamer-ffmpeg
#PACK de APP##
yum -y install --skip-broken audacity-freeworld gimp gparted sound-juicer clementine gwget vlc kdenlive firefox unrar p7zip p7zip-plugins java-1.6.0-openjdk ntfs-config kid3 java-1.6.0-openjdk-plugin btrfs-progs wget rfkill alsa-plugins-pulseaudio flash-plugin gnome-shell-extension-common bash-completion dconf-editor guake gnome-shell-extensions-alternative-status-menu gnome-shell-extensions-drive-menu gnome-shell-extensions-places-menu gnome-tweak-tool shutter sugar-emulator redhat-lsb chromium gnome-shell-extension-alternate-tab gnome-shell-extensions-common
##Pack office##
yum -y groupinstall "Oficina y Productividad"
##SUGAR##
yum -y groupinstall "Entorno de Escritorio Sugar"
##Fuentes de microsoft#
wget http://physics.bgu.ac.il/DOWNLOADS/RPMs/msttcorefonts-2.0-2.noarch.rpm
rpm -ivh msttcorefonts-2.0-2.noarch.rpm
